import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { Pipe, EventEmitter, Component, ChangeDetectionStrategy, Input, Output, ViewChild } from '@angular/core';
import * as i4 from '@angular/material/checkbox';
import { MatCheckboxModule } from '@angular/material/checkbox';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import * as i3 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import * as i3$1 from '@angular/material/paginator';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { HttpHeaders } from '@angular/common/http';

class ButtonClassPipe {
    transform(value, size, custom) {
        let buttonClass = '';
        switch (value) {
            case 'fill':
                buttonClass = 'ff-btn-fill';
                break;
            case 'stroked':
                buttonClass = 'ff-btn-stroked';
                break;
            case 'secondary':
                buttonClass = 'ff-btn-secondary';
                break;
            default:
                buttonClass = 'ff-btn-fill';
                break;
        }
        if (size === 'medium') {
            buttonClass += ` md`;
        }
        else {
            buttonClass += ` lg`;
        }
        if (custom) {
            buttonClass += ` ${custom}`;
        }
        return buttonClass;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonClassPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: ButtonClassPipe, isStandalone: true, name: "generateBtnClass" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonClassPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'generateBtnClass',
                    standalone: true,
                }]
        }] });

class ButtonsComponent {
    constructor() {
        /**
         * Event emitted when the button is clicked.
         * Emits a boolean value representing the click event.
         *
         * @type {EventEmitter<boolean>}
         * @memberof ButtonsComponent
         */
        this.buttonClicked = new EventEmitter();
    }
    buttonClick() {
        this.buttonClicked.emit(true);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ButtonsComponent, isStandalone: true, selector: "app-buttons", inputs: { buttonType: "buttonType", buttonSize: "buttonSize", customId: "customId", buttonClass: "buttonClass", isDisabled: "isDisabled", tooltip: "tooltip" }, outputs: { buttonClicked: "buttonClicked" }, ngImport: i0, template: "<button type=\"button\" [ngClass]=\"buttonType | generateBtnClass:buttonSize:buttonClass \" (click)=\"buttonClick()\"\r\n    [disabled]=\"isDisabled\" [title]=\"tooltip || ''\" [id]=\"customId || 'actionButton'\">\r\n    <ng-content></ng-content>\r\n</button>", styles: [".ff-btn-secondary,.ff-btn-fill,.ff-btn-stroked{cursor:pointer;font-family:Moderat Regular,sans-serif;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;border:none;font-size:14px;height:auto!important;margin:5px;white-space:nowrap;border-radius:5px;display:flex;align-items:center;line-height:1}.lg.ff-btn-secondary,.lg.ff-btn-fill,.lg.ff-btn-stroked{padding:12px 25px}@media only screen and (min-width: 1600px){.lg.ff-btn-secondary,.lg.ff-btn-fill,.lg.ff-btn-stroked{padding:15px 25px}}.md.ff-btn-secondary,.md.ff-btn-fill,.md.ff-btn-stroked{padding:7.5px 15px}@media only screen and (min-width: 1600px){.md.ff-btn-secondary,.md.ff-btn-fill,.md.ff-btn-stroked{padding:12px 16px}}.ff-btn-secondary:disabled,.ff-btn-fill:disabled,.ff-btn-stroked:disabled{background:var(--border-color);border:none;color:var(--font-color);cursor:default}.ff-btn-stroked{background-color:var(--color-white);color:var(--color-secondary);border:1px solid var(--color-secondary)}.ff-btn-fill{background-color:var(--color-secondary);color:var(--color-white)}.ff-btn-secondary{background-color:var(--color-white);color:var(--font-color);border:1px solid var(--font-color);height:34px!important;padding:10px!important}@media only screen and (min-width: 1600px){.ff-btn-secondary{padding:10px 15px!important;height:40px!important}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: ButtonClassPipe, name: "generateBtnClass" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ButtonsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-buttons', standalone: true, imports: [CommonModule, ButtonClassPipe], changeDetection: ChangeDetectionStrategy.OnPush, template: "<button type=\"button\" [ngClass]=\"buttonType | generateBtnClass:buttonSize:buttonClass \" (click)=\"buttonClick()\"\r\n    [disabled]=\"isDisabled\" [title]=\"tooltip || ''\" [id]=\"customId || 'actionButton'\">\r\n    <ng-content></ng-content>\r\n</button>", styles: [".ff-btn-secondary,.ff-btn-fill,.ff-btn-stroked{cursor:pointer;font-family:Moderat Regular,sans-serif;transition:color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;border:none;font-size:14px;height:auto!important;margin:5px;white-space:nowrap;border-radius:5px;display:flex;align-items:center;line-height:1}.lg.ff-btn-secondary,.lg.ff-btn-fill,.lg.ff-btn-stroked{padding:12px 25px}@media only screen and (min-width: 1600px){.lg.ff-btn-secondary,.lg.ff-btn-fill,.lg.ff-btn-stroked{padding:15px 25px}}.md.ff-btn-secondary,.md.ff-btn-fill,.md.ff-btn-stroked{padding:7.5px 15px}@media only screen and (min-width: 1600px){.md.ff-btn-secondary,.md.ff-btn-fill,.md.ff-btn-stroked{padding:12px 16px}}.ff-btn-secondary:disabled,.ff-btn-fill:disabled,.ff-btn-stroked:disabled{background:var(--border-color);border:none;color:var(--font-color);cursor:default}.ff-btn-stroked{background-color:var(--color-white);color:var(--color-secondary);border:1px solid var(--color-secondary)}.ff-btn-fill{background-color:var(--color-secondary);color:var(--color-white)}.ff-btn-secondary{background-color:var(--color-white);color:var(--font-color);border:1px solid var(--font-color);height:34px!important;padding:10px!important}@media only screen and (min-width: 1600px){.ff-btn-secondary{padding:10px 15px!important;height:40px!important}}\n"] }]
        }], propDecorators: { buttonType: [{
                type: Input
            }], buttonSize: [{
                type: Input
            }], customId: [{
                type: Input
            }], buttonClass: [{
                type: Input
            }], isDisabled: [{
                type: Input
            }], tooltip: [{
                type: Input
            }], buttonClicked: [{
                type: Output
            }] } });

/**
 * ButtonsComponent is a reusable component that represents a button with different styles and sizes.
 * It supports various customization options such as button type, size, additional classes, and disabled state.
 *
 * Usage:
 *
 * <app-buttons
 *   [buttonType]="'fill' | 'stroked' | 'secondary'"
 *   [buttonSize]="'medium' | 'large'"
 *   [buttonClass]="customButtonClass"
 *   [isDisabled]="disabledState"
 *   [tooltip]="tooltipText"
 *   (buttonClicked)="handleButtonClick()"
 * >
 *   Button Text
 * </app-buttons>
 *
 * @example
 *
 * <app-buttons
 *   buttonType="fill"
 *   buttonSize="large"
 *   buttonClass="custom-class"
 *   isDisabled="false"
 *   tooltip="Click me!"
 *   (buttonClicked)="handleButtonClick()"
 * >
 *   Button Text
 * </app-buttons>
 *
 */

class ActionButtonsComponent {
    constructor() {
        this.buttonsClicked = new EventEmitter();
    }
    buttonNavigation(type) {
        this.buttonsClicked.next(type);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ActionButtonsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: ActionButtonsComponent, isStandalone: true, selector: "app-action-buttons", inputs: { buttonNextState: "buttonNextState", buttonPrevText: "buttonPrevText", customId: "customId" }, outputs: { buttonsClicked: "buttonsClicked" }, ngImport: i0, template: `
    <section class="action-section">
      <app-buttons
        buttonType="stroked"
        customId="backButton"
        (buttonClicked)="buttonNavigation('prev')"
      >
        {{ buttonPrevText ? buttonPrevText : 'Back' }}
      </app-buttons>
      <app-buttons
        buttonType="fill"
        [isDisabled]="buttonNextState.disabled"
        [customId]="customId"
        (buttonClicked)="buttonNavigation('next')"
      >
        {{ buttonNextState.buttonText }}
      </app-buttons>
    </section>
  `, isInline: true, styles: [".action-section{display:flex;align-items:center;justify-content:space-between;width:100%;margin-top:25px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "component", type: ButtonsComponent, selector: "app-buttons", inputs: ["buttonType", "buttonSize", "customId", "buttonClass", "isDisabled", "tooltip"], outputs: ["buttonClicked"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: ActionButtonsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-action-buttons', standalone: true, imports: [CommonModule, ButtonsComponent], template: `
    <section class="action-section">
      <app-buttons
        buttonType="stroked"
        customId="backButton"
        (buttonClicked)="buttonNavigation('prev')"
      >
        {{ buttonPrevText ? buttonPrevText : 'Back' }}
      </app-buttons>
      <app-buttons
        buttonType="fill"
        [isDisabled]="buttonNextState.disabled"
        [customId]="customId"
        (buttonClicked)="buttonNavigation('next')"
      >
        {{ buttonNextState.buttonText }}
      </app-buttons>
    </section>
  `, styles: [".action-section{display:flex;align-items:center;justify-content:space-between;width:100%;margin-top:25px}\n"] }]
        }], propDecorators: { buttonNextState: [{
                type: Input
            }], buttonPrevText: [{
                type: Input
            }], customId: [{
                type: Input
            }], buttonsClicked: [{
                type: Output
            }] } });

class SortCustomComponent {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SortCustomComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: SortCustomComponent, isStandalone: true, selector: "app-sort-custom", inputs: { filterValues: "filterValues", columnName: "columnName" }, ngImport: i0, template: "<article class=\"sort-wrap ff-flex-align-center flex-column\">\r\n    <span class=\"arrow-up\"\r\n        [ngClass]=\"(filterValues?.orderBy === 'asc'&& filterValues?.sortBy===columnName)?'active':'inactive'\" id=\"arrowUp\"></span>\r\n    <span class=\"arrow-down\"\r\n        [ngClass]=\"(filterValues?.orderBy === 'desc'&& filterValues?.sortBy===columnName)?'active':'inactive'\" id=\"arrowDown\"></span>\r\n</article>", styles: [".sort-wrap{margin-left:10px}.sort-wrap .arrow-down,.sort-wrap .arrow-up{width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent}.sort-wrap .arrow-up{border-bottom:6px solid;margin-bottom:2px}.sort-wrap .arrow-up.active{border-bottom-color:var(--font-color)}.sort-wrap .arrow-up.inactive{border-bottom-color:var(--color-sort-inactive)}.sort-wrap .arrow-down{border-top:6px solid}.sort-wrap .arrow-down.active{border-top-color:var(--font-color)}.sort-wrap .arrow-down.inactive{border-top-color:var(--color-sort-inactive)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: SortCustomComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-sort-custom', standalone: true, imports: [CommonModule], template: "<article class=\"sort-wrap ff-flex-align-center flex-column\">\r\n    <span class=\"arrow-up\"\r\n        [ngClass]=\"(filterValues?.orderBy === 'asc'&& filterValues?.sortBy===columnName)?'active':'inactive'\" id=\"arrowUp\"></span>\r\n    <span class=\"arrow-down\"\r\n        [ngClass]=\"(filterValues?.orderBy === 'desc'&& filterValues?.sortBy===columnName)?'active':'inactive'\" id=\"arrowDown\"></span>\r\n</article>", styles: [".sort-wrap{margin-left:10px}.sort-wrap .arrow-down,.sort-wrap .arrow-up{width:0;height:0;border-left:6px solid transparent;border-right:6px solid transparent}.sort-wrap .arrow-up{border-bottom:6px solid;margin-bottom:2px}.sort-wrap .arrow-up.active{border-bottom-color:var(--font-color)}.sort-wrap .arrow-up.inactive{border-bottom-color:var(--color-sort-inactive)}.sort-wrap .arrow-down{border-top:6px solid}.sort-wrap .arrow-down.active{border-top-color:var(--font-color)}.sort-wrap .arrow-down.inactive{border-top-color:var(--color-sort-inactive)}\n"] }]
        }], propDecorators: { filterValues: [{
                type: Input
            }], columnName: [{
                type: Input
            }] } });

var LoaderType;
(function (LoaderType) {
    LoaderType["Type1"] = "type1";
    LoaderType["Type2"] = "type2";
    LoaderType["Default"] = "default";
})(LoaderType || (LoaderType = {}));
class LoaderComponent {
    constructor() {
        this.loaderType = LoaderType.Default;
        this.LoaderType = LoaderType;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoaderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: LoaderComponent, isStandalone: true, selector: "app-loader", inputs: { loaderText: "loaderText", noText: "noText", loaderType: "loaderType" }, ngImport: i0, template: "<section class=\"loader-wrapper\">\n    <ng-container *ngIf=\"loaderType === LoaderType.Default\">\n        <!-- Default loader SVG code -->\n        <svg class=\"size-60\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"144px\"\n            height=\"144px\" viewBox=\"10 0 80 80\" preserveAspectRatio=\"xMidYMid\">\n            <circle cx=\"50\" cy=\"50\" r=\"18\" class=\"circle1\" stroke-width=\"2\" fill=\"none\"></circle>\n            <circle cx=\"50\" cy=\"50\" r=\"18\" class=\"circle2\" stroke-width=\"4\" stroke-linecap=\"round\" fill=\"none\"\n                transform=\"rotate(12.575 50 50)\">\n                <animateTransform attributeName=\"transform\" type=\"rotate\" repeatCount=\"indefinite\"\n                    dur=\"1.7241379310344827s\" values=\"0 50 50;180 50 50;720 50 50\" keyTimes=\"0;0.5;1\">\n                </animateTransform>\n                <animate attributeName=\"stroke-dasharray\" repeatCount=\"indefinite\" dur=\"1.7241379310344827s\"\n                    values=\"11.309733552923255 101.7876019763093;56.548667764616276 56.548667764616276;11.309733552923255 101.7876019763093\"\n                    keyTimes=\"0;0.5;1\"></animate>\n            </circle>\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"loaderType === LoaderType.Type1\">\n        <!-- Type 1 loader SVG code -->\n        <svg height=\"200\" width=\"200\">\n            <circle id=\"c1\" cx=\"100\" cy=\"100\" r=\"30\" stroke=\"#4dcaf4\" stroke-width=\"5\" fill=\"transparent\" />\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"loaderType === LoaderType.Type2\">\n        <!-- Type 2 loader its type 1 and smaller SVG code -->\n        <svg height=\"60\" width=\"60\">\n            <circle id=\"c1\" cx=\"30\" cy=\"30\" r=\"20\" stroke=\"#4dcaf4\" stroke-width=\"5\" fill=\"transparent\" />\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"!noText\">\n        <span class=\"paragraph1\">{{ loaderText }}...</span>\n    </ng-container>\n</section>\n", styles: [".circle1{stroke:var(--color-primary-1)}.circle2{stroke:var(--color-secondary)}.loader-wrapper{display:flex;align-items:center;justify-content:center;flex-direction:column;padding-bottom:20px}#c1{stroke-dasharray:20;stroke-dashoffset:500;animation:loading2 2s ease infinite;-webkit-animation:loading2 2s ease infinite}@keyframes loading2{to{stroke-dashoffset:0}}#c2{stroke-dasharray:80;stroke-dashoffset:500;animation:loading3 2s linear infinite;-webkit-animation:loading3 2s linear infinite}@keyframes loading3{to{stroke-dashoffset:0}}#c3{stroke-dasharray:20;stroke-dashoffset:200;animation:loading4 2s linear infinite;-webkit-animation:loading4 2s linear infinite}@keyframes loading4{to{stroke-dashoffset:0}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: LoaderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-loader', standalone: true, imports: [CommonModule], template: "<section class=\"loader-wrapper\">\n    <ng-container *ngIf=\"loaderType === LoaderType.Default\">\n        <!-- Default loader SVG code -->\n        <svg class=\"size-60\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" width=\"144px\"\n            height=\"144px\" viewBox=\"10 0 80 80\" preserveAspectRatio=\"xMidYMid\">\n            <circle cx=\"50\" cy=\"50\" r=\"18\" class=\"circle1\" stroke-width=\"2\" fill=\"none\"></circle>\n            <circle cx=\"50\" cy=\"50\" r=\"18\" class=\"circle2\" stroke-width=\"4\" stroke-linecap=\"round\" fill=\"none\"\n                transform=\"rotate(12.575 50 50)\">\n                <animateTransform attributeName=\"transform\" type=\"rotate\" repeatCount=\"indefinite\"\n                    dur=\"1.7241379310344827s\" values=\"0 50 50;180 50 50;720 50 50\" keyTimes=\"0;0.5;1\">\n                </animateTransform>\n                <animate attributeName=\"stroke-dasharray\" repeatCount=\"indefinite\" dur=\"1.7241379310344827s\"\n                    values=\"11.309733552923255 101.7876019763093;56.548667764616276 56.548667764616276;11.309733552923255 101.7876019763093\"\n                    keyTimes=\"0;0.5;1\"></animate>\n            </circle>\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"loaderType === LoaderType.Type1\">\n        <!-- Type 1 loader SVG code -->\n        <svg height=\"200\" width=\"200\">\n            <circle id=\"c1\" cx=\"100\" cy=\"100\" r=\"30\" stroke=\"#4dcaf4\" stroke-width=\"5\" fill=\"transparent\" />\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"loaderType === LoaderType.Type2\">\n        <!-- Type 2 loader its type 1 and smaller SVG code -->\n        <svg height=\"60\" width=\"60\">\n            <circle id=\"c1\" cx=\"30\" cy=\"30\" r=\"20\" stroke=\"#4dcaf4\" stroke-width=\"5\" fill=\"transparent\" />\n        </svg>\n    </ng-container>\n\n    <ng-container *ngIf=\"!noText\">\n        <span class=\"paragraph1\">{{ loaderText }}...</span>\n    </ng-container>\n</section>\n", styles: [".circle1{stroke:var(--color-primary-1)}.circle2{stroke:var(--color-secondary)}.loader-wrapper{display:flex;align-items:center;justify-content:center;flex-direction:column;padding-bottom:20px}#c1{stroke-dasharray:20;stroke-dashoffset:500;animation:loading2 2s ease infinite;-webkit-animation:loading2 2s ease infinite}@keyframes loading2{to{stroke-dashoffset:0}}#c2{stroke-dasharray:80;stroke-dashoffset:500;animation:loading3 2s linear infinite;-webkit-animation:loading3 2s linear infinite}@keyframes loading3{to{stroke-dashoffset:0}}#c3{stroke-dasharray:20;stroke-dashoffset:200;animation:loading4 2s linear infinite;-webkit-animation:loading4 2s linear infinite}@keyframes loading4{to{stroke-dashoffset:0}}\n"] }]
        }], propDecorators: { loaderText: [{
                type: Input
            }], noText: [{
                type: Input
            }], loaderType: [{
                type: Input
            }] } });

/**
 * @component LoaderComponent
 * @description
 *   The `LoaderComponent` is a reusable Angular component that displays a loader with customizable text and styles.
 *   It can be used to indicate loading or processing states in an Angular application.
 *
 * @usage
 *   ```
 *   <app-loader
 *     [loaderText]="loadingText"
 *     [noText]="hideText"
 *     [loaderType]="selectedLoaderType"
 *   ></app-loader>
 *   ```
 *
 * @inputs
 *   - `loaderText` (string): The text to display alongside the loader. (Optional)
 *   - `noText` (boolean): Determines whether to hide the loader text. Defaults to `false`. (Optional)
 *   - `loaderType` (string): The type of loader to display. Possible values are `LoaderType.Type1`, `LoaderType.Type2`, `LoaderType.Type3`, and `LoaderType.Default`. Defaults to `LoaderType.Default`. (Optional)
 *
 * @enums
 *   - `LoaderType`: An enumeration that represents the available loader types.
 *     - `Type1`: Type 1 loader style.
 *     - `Type2`: Type 2 loader style.
 *     - `Type3`: Type 3 loader style.
 *     - `Default`: Default loader style.
 *
 * @example
 *   ```typescript
 *   import { Component } from '@angular/core';
 *
 *   @Component({
 *     selector: 'app-example',
 *     template: `
 *       <app-loader
 *         [loaderText]="'Loading...'"
 *         [noText]="false"
 *         [loaderType]="LoaderType.Type1"
 *       ></app-loader>
 *     `,
 *   })
 *   export class ExampleComponent {
 *     readonly LoaderType = LoaderType;
 *   }
 *   ```
 *
 * @styles
 *   The `LoaderComponent` applies the following CSS classes:
 *   - `.loader-container`: The main container of the loader component.
 *   - `.loader-text`: The CSS class for the loader text.
 *   - `.circle1`, `.circle2`: Applied to customize the colors of the circles in the loader SVG code.
 *   - `.loader-wrapper`: The CSS class for the wrapper element of the loader component.
 *
 * @dependencies
 *   This component requires the following Angular modules and dependencies to be imported:
 *   - `@angular/core`: Angular core module.
 *   - `@angular/common`: Angular common module.
 *
 * @version 1.0.0
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
class FairFoodCustomTabComponent {
    constructor() {
        this.tabChanged = new EventEmitter();
    }
    ngOnChanges(changes) {
        const { tabGroupItems } = changes;
        if (tabGroupItems) {
            this.tabList = JSON.parse(JSON.stringify(tabGroupItems.currentValue));
        }
    }
    changeTab(tabItem) {
        if (this.withDescription) {
            tabItem.active ? this.tabChanged.emit(tabItem) : console.log('Disabled');
        }
        else {
            this.tabChanged.emit(tabItem);
        }
    }
    addTab(item) {
        const found = this.tabList.findIndex(t => t.id === item.id);
        if (found !== -1) {
            item.selected = false;
            this.tabList.splice(found, 1);
            this.activeTabId = this.tabList[0].id;
            this.tabChanged.emit(this.tabList[0]);
        }
        else {
            item.selected = true;
            this.tabList.push(item);
        }
    }
    trackByFn(index) {
        return index;
    }
    ngOnDestroy() {
        this.moreTabs = [];
        this.tabGroupItems = [];
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FairFoodCustomTabComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FairFoodCustomTabComponent, isStandalone: true, selector: "app-ff-custom-tab", inputs: { tabGroupItems: "tabGroupItems", activeTabId: "activeTabId", moreTabs: "moreTabs", withDescription: "withDescription" }, outputs: { tabChanged: "tabChanged" }, usesOnChanges: true, ngImport: i0, template: "<ul class=\"tab-group ff-flex-start\" [class.border-tab]=\"withDescription\">\r\n    <!-- stock process tab contains state. So it should be handled seperately -->\r\n    <ng-container *ngIf=\"!withDescription; else withDescriptionTabs\">\r\n        <ng-container *ngFor=\"let tr of tabList; trackBy: trackByFn; let i = index\">\r\n            <li class=\"tab-item font-1-bold pointer\" [ngClass]=\"activeTabId === tr.id? 'active': ''\"\r\n                (click)=\"changeTab(tr)\" id=\"tabItem-{{i}}\">\r\n                {{tr?.name}}\r\n            </li>\r\n        </ng-container>\r\n        <li class=\"tab-item font-1-bold pointer\" [matMenuTriggerFor]=\"moreTabsMenu\" *ngIf=\"moreTabs?.length\"\r\n            id=\"moreButton\">\r\n            More <mat-icon>keyboard_arrow_down</mat-icon>\r\n        </li>\r\n        <mat-menu class=\"mat-menu more-filters\" #moreTabsMenu=\"matMenu\" xPosition=\"after\">\r\n            <ul *ngIf=\"moreTabs?.length\" (click)=\"$event.stopPropagation()\">\r\n                <li *ngFor=\"let item of moreTabs; trackBy: trackByFn; let j=index\">\r\n                    <mat-checkbox class=\"w-100\" [checked]=\"item.selected\"\r\n                        (click)=\"addTab(item)\" id=\"check{{j}}\">{{item.name}}</mat-checkbox>\r\n                </li>\r\n            </ul>\r\n        </mat-menu>\r\n    </ng-container>\r\n\r\n    <ng-template #withDescriptionTabs>\r\n        <ng-container *ngFor=\"let ta of tabList; trackBy: trackByFn; let i = index\">\r\n            <li class=\"tab-item font-1-bold pointer no-left-p\" [ngClass]=\"activeTabId === ta.id? 'active': ''\"\r\n                (click)=\"changeTab(ta)\" id=\"withDescription-{{i}}\">\r\n                <mat-icon [ngClass]=\"ta?.active ? 'set-primary': 'set-disabled'\">check_circle</mat-icon>\r\n                <aside class=\"details\" [class.disabled-details]=\"!ta.active\">\r\n                    <span>{{ta?.name}}</span>\r\n                    <p *ngIf=\"ta?.description\">{{ta?.description}}</p>\r\n                </aside>\r\n            </li>\r\n        </ng-container>\r\n    </ng-template>\r\n\r\n</ul>", styles: ["::ng-deep .more-filters .mat-mdc-menu-content{padding:15px;width:210px}::ng-deep .more-filters .mat-mdc-menu-content ul{list-style:none;padding:0;margin:0}::ng-deep .more-filters .mat-mdc-menu-content ul li{padding:5px 3px;color:var(--font-color);font-family:var(--font-regular);font-size:14px}ul{list-style:none;margin:0}.tab-group{padding:0;margin-bottom:-7px;overflow-x:auto}.tab-group.border-tab{border-bottom:1px solid var(--border-color)}.tab-group::-webkit-scrollbar{width:10px;height:8px}.tab-group::-webkit-scrollbar-track{border-radius:2px}.tab-group::-webkit-scrollbar-thumb{border-radius:3px;background-color:var(--color-scrollbar)}.tab-group .tab-item{font-size:14px;color:var(--font-color);padding:20px;display:flex;align-items:center;justify-content:center;white-space:nowrap}@media only screen and (min-width: 1600px){.tab-group .tab-item{font-size:16px}}.tab-group .tab-item.active{border-bottom:5px solid var(--color-primary-2);transition:all .3s linear;padding:15px 20px}.tab-group .tab-item.no-left-p{padding-left:0;padding-bottom:10px}.tab-group .tab-item .details{display:flex;flex-direction:column;padding-left:15px}.tab-group .tab-item .details.disabled-details{color:var(--color-disabled)}.tab-group .tab-item .details p{font-family:var(--font-regular);font-size:12px;color:var(--font-color-2);margin:0}.tab-group .tab-item .set-primary{color:var(--font-color-2)}.tab-group .tab-item .set-disabled{color:var(--border-color)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i3.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { kind: "directive", type: i3.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatCheckboxModule }, { kind: "component", type: i4.MatCheckbox, selector: "mat-checkbox", inputs: ["disableRipple", "color", "tabIndex"], exportAs: ["matCheckbox"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FairFoodCustomTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-custom-tab', standalone: true, imports: [CommonModule, MatIconModule, MatMenuModule, MatCheckboxModule], template: "<ul class=\"tab-group ff-flex-start\" [class.border-tab]=\"withDescription\">\r\n    <!-- stock process tab contains state. So it should be handled seperately -->\r\n    <ng-container *ngIf=\"!withDescription; else withDescriptionTabs\">\r\n        <ng-container *ngFor=\"let tr of tabList; trackBy: trackByFn; let i = index\">\r\n            <li class=\"tab-item font-1-bold pointer\" [ngClass]=\"activeTabId === tr.id? 'active': ''\"\r\n                (click)=\"changeTab(tr)\" id=\"tabItem-{{i}}\">\r\n                {{tr?.name}}\r\n            </li>\r\n        </ng-container>\r\n        <li class=\"tab-item font-1-bold pointer\" [matMenuTriggerFor]=\"moreTabsMenu\" *ngIf=\"moreTabs?.length\"\r\n            id=\"moreButton\">\r\n            More <mat-icon>keyboard_arrow_down</mat-icon>\r\n        </li>\r\n        <mat-menu class=\"mat-menu more-filters\" #moreTabsMenu=\"matMenu\" xPosition=\"after\">\r\n            <ul *ngIf=\"moreTabs?.length\" (click)=\"$event.stopPropagation()\">\r\n                <li *ngFor=\"let item of moreTabs; trackBy: trackByFn; let j=index\">\r\n                    <mat-checkbox class=\"w-100\" [checked]=\"item.selected\"\r\n                        (click)=\"addTab(item)\" id=\"check{{j}}\">{{item.name}}</mat-checkbox>\r\n                </li>\r\n            </ul>\r\n        </mat-menu>\r\n    </ng-container>\r\n\r\n    <ng-template #withDescriptionTabs>\r\n        <ng-container *ngFor=\"let ta of tabList; trackBy: trackByFn; let i = index\">\r\n            <li class=\"tab-item font-1-bold pointer no-left-p\" [ngClass]=\"activeTabId === ta.id? 'active': ''\"\r\n                (click)=\"changeTab(ta)\" id=\"withDescription-{{i}}\">\r\n                <mat-icon [ngClass]=\"ta?.active ? 'set-primary': 'set-disabled'\">check_circle</mat-icon>\r\n                <aside class=\"details\" [class.disabled-details]=\"!ta.active\">\r\n                    <span>{{ta?.name}}</span>\r\n                    <p *ngIf=\"ta?.description\">{{ta?.description}}</p>\r\n                </aside>\r\n            </li>\r\n        </ng-container>\r\n    </ng-template>\r\n\r\n</ul>", styles: ["::ng-deep .more-filters .mat-mdc-menu-content{padding:15px;width:210px}::ng-deep .more-filters .mat-mdc-menu-content ul{list-style:none;padding:0;margin:0}::ng-deep .more-filters .mat-mdc-menu-content ul li{padding:5px 3px;color:var(--font-color);font-family:var(--font-regular);font-size:14px}ul{list-style:none;margin:0}.tab-group{padding:0;margin-bottom:-7px;overflow-x:auto}.tab-group.border-tab{border-bottom:1px solid var(--border-color)}.tab-group::-webkit-scrollbar{width:10px;height:8px}.tab-group::-webkit-scrollbar-track{border-radius:2px}.tab-group::-webkit-scrollbar-thumb{border-radius:3px;background-color:var(--color-scrollbar)}.tab-group .tab-item{font-size:14px;color:var(--font-color);padding:20px;display:flex;align-items:center;justify-content:center;white-space:nowrap}@media only screen and (min-width: 1600px){.tab-group .tab-item{font-size:16px}}.tab-group .tab-item.active{border-bottom:5px solid var(--color-primary-2);transition:all .3s linear;padding:15px 20px}.tab-group .tab-item.no-left-p{padding-left:0;padding-bottom:10px}.tab-group .tab-item .details{display:flex;flex-direction:column;padding-left:15px}.tab-group .tab-item .details.disabled-details{color:var(--color-disabled)}.tab-group .tab-item .details p{font-family:var(--font-regular);font-size:12px;color:var(--font-color-2);margin:0}.tab-group .tab-item .set-primary{color:var(--font-color-2)}.tab-group .tab-item .set-disabled{color:var(--border-color)}\n"] }]
        }], propDecorators: { tabGroupItems: [{
                type: Input
            }], activeTabId: [{
                type: Input
            }], moreTabs: [{
                type: Input
            }], withDescription: [{
                type: Input
            }], tabChanged: [{
                type: Output
            }] } });

/* eslint-disable @typescript-eslint/no-explicit-any */
class FfPaginationComponent {
    constructor() {
        this.hidePageSize = false;
        this.defaultPageSize = 10;
        this.paginationAction = new EventEmitter();
    }
    /**
     * This method is called when there are changes in the input properties.
     * It adjusts the paginator's pageSize and pageIndex if customPageSize is provided.
     * @param changes - The changes in input properties.
     */
    ngOnChanges(changes) {
        const { customPageSize } = changes;
        if (customPageSize?.currentValue && this.paginator) {
            this.paginator.pageSize = customPageSize.currentValue.limit;
            this.paginator.pageIndex = customPageSize.currentValue.offset;
        }
    }
    /**
     * Get the page size options based on the totalCount.
     * @returns An array of page size options.
     */
    getPageSizeOptions() {
        if (this.totalCount > 20) {
            return [10, 20, 50];
        }
        else {
            return [10, 20];
        }
    }
    /**
     * Handles the page event emitted by the paginator.
     * @param e - The page event.
     */
    pageEvent(e) {
        e.length = this.defaultPageSize;
        this.paginator.pageSize = e?.pageSize || this.defaultPageSize;
        this.paginationAction.emit({
            limit: this.paginator.pageSize,
            offset: this.paginator.pageIndex * this.paginator.pageSize,
            type: 'page',
        });
    }
    /**
     * Sets the page size and resets pageIndex to 0.
     * @param pageSize - The selected page size.
     */
    pageSizeSetter(pageSize) {
        this.paginator.pageIndex = 0;
        this.paginator.pageSize = pageSize;
        this.paginationAction.emit({
            limit: this.paginator.pageSize,
            offset: 0,
            type: 'perPage',
        });
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfPaginationComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "16.2.12", type: FfPaginationComponent, isStandalone: true, selector: "app-ff-pagination", inputs: { totalCount: "totalCount", customPageSize: "customPageSize", hidePageSize: "hidePageSize", defaultPageSize: "defaultPageSize" }, outputs: { paginationAction: "paginationAction" }, viewQueries: [{ propertyName: "paginator", first: true, predicate: MatPaginator, descendants: true }], usesOnChanges: true, ngImport: i0, template: "<aside aria-label=\"paginator wrapper\" class=\"ff-flex-between custom-style-paginator-select\">\r\n    <article class=\"per-page-wrapper\" *ngIf=\"!hidePageSize\">\r\n        <span class=\"custom-text\">\r\n            Items per page: &nbsp;\r\n        </span>\r\n        <aside aria-label=\"custom material pagesize dropdown\" class=\"page-size-dropdown pointer\"\r\n            [matMenuTriggerFor]=\"pageSizeMenu\" id=\"pageSize\">\r\n            {{(paginator?.pageSize || defaultPageSize)}} <mat-icon>keyboard_arrow_down</mat-icon>\r\n        </aside>\r\n        <mat-menu class=\"mat-menu\" #pageSizeMenu=\"matMenu\" xPosition=\"after\">\r\n            <ul class=\"dropdown-page\">\r\n                <li *ngFor=\"let item of getPageSizeOptions()\" (click)=\"pageSizeSetter(item)\" id=\"page{{item}}\">\r\n                    {{item}}\r\n                </li>\r\n            </ul>\r\n        </mat-menu>\r\n    </article>\r\n\r\n    <mat-paginator [length]=\"totalCount\" [pageSize]=\"defaultPageSize\" [hidePageSize]=\"true\" (page)=\"pageEvent($event)\">\r\n    </mat-paginator>\r\n</aside>", styles: ["::ng-deep .mat-mdc-paginator-page-size{position:relative;right:80px}::ng-deep .mat-mdc-paginator-page-size .mat-form-field-appearance-legacy .mat-form-field-infix{padding-bottom:2px!important;color:var(--color-secondary)}.mat-mdc-paginator-range-label{margin-right:45px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-previous{right:110px;margin-left:0}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-next{right:17px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-range-label{height:40px;position:absolute;margin-right:0;display:flex;align-items:center;justify-content:center;right:86px;color:var(--font-color);font-size:14px;font-family:var(--font-regular);line-height:0px;top:auto}ul{list-style:none;margin:0}.custom-style-paginator-select{margin-top:10px;position:relative}@media only screen and (min-width: 992px){.custom-style-paginator-select{justify-content:flex-end}}.dropdown-page{list-style:none;padding-left:10px;margin:0}.dropdown-page li{padding:4px;cursor:pointer}.page-size-dropdown{border-radius:6px;border:1px solid var(--border-color);padding:4px 12px;color:var(--font-color);min-width:100px;display:flex;justify-content:space-between}.per-page-wrapper{display:flex;align-items:center}@media only screen and (min-width: 992px){.per-page-wrapper{position:relative;right:8vw}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i3.MatMenu, selector: "mat-menu", exportAs: ["matMenu"] }, { kind: "directive", type: i3.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatPaginatorModule }, { kind: "component", type: i3$1.MatPaginator, selector: "mat-paginator", inputs: ["disabled"], exportAs: ["matPaginator"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i2.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FfPaginationComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-ff-pagination', standalone: true, imports: [CommonModule, MatMenuModule, MatPaginatorModule, MatIconModule], template: "<aside aria-label=\"paginator wrapper\" class=\"ff-flex-between custom-style-paginator-select\">\r\n    <article class=\"per-page-wrapper\" *ngIf=\"!hidePageSize\">\r\n        <span class=\"custom-text\">\r\n            Items per page: &nbsp;\r\n        </span>\r\n        <aside aria-label=\"custom material pagesize dropdown\" class=\"page-size-dropdown pointer\"\r\n            [matMenuTriggerFor]=\"pageSizeMenu\" id=\"pageSize\">\r\n            {{(paginator?.pageSize || defaultPageSize)}} <mat-icon>keyboard_arrow_down</mat-icon>\r\n        </aside>\r\n        <mat-menu class=\"mat-menu\" #pageSizeMenu=\"matMenu\" xPosition=\"after\">\r\n            <ul class=\"dropdown-page\">\r\n                <li *ngFor=\"let item of getPageSizeOptions()\" (click)=\"pageSizeSetter(item)\" id=\"page{{item}}\">\r\n                    {{item}}\r\n                </li>\r\n            </ul>\r\n        </mat-menu>\r\n    </article>\r\n\r\n    <mat-paginator [length]=\"totalCount\" [pageSize]=\"defaultPageSize\" [hidePageSize]=\"true\" (page)=\"pageEvent($event)\">\r\n    </mat-paginator>\r\n</aside>", styles: ["::ng-deep .mat-mdc-paginator-page-size{position:relative;right:80px}::ng-deep .mat-mdc-paginator-page-size .mat-form-field-appearance-legacy .mat-form-field-infix{padding-bottom:2px!important;color:var(--color-secondary)}.mat-mdc-paginator-range-label{margin-right:45px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-previous{right:110px;margin-left:0}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-navigation-next{right:17px}::ng-deep .mat-mdc-paginator .mat-mdc-paginator-range-label{height:40px;position:absolute;margin-right:0;display:flex;align-items:center;justify-content:center;right:86px;color:var(--font-color);font-size:14px;font-family:var(--font-regular);line-height:0px;top:auto}ul{list-style:none;margin:0}.custom-style-paginator-select{margin-top:10px;position:relative}@media only screen and (min-width: 992px){.custom-style-paginator-select{justify-content:flex-end}}.dropdown-page{list-style:none;padding-left:10px;margin:0}.dropdown-page li{padding:4px;cursor:pointer}.page-size-dropdown{border-radius:6px;border:1px solid var(--border-color);padding:4px 12px;color:var(--font-color);min-width:100px;display:flex;justify-content:space-between}.per-page-wrapper{display:flex;align-items:center}@media only screen and (min-width: 992px){.per-page-wrapper{position:relative;right:8vw}}\n"] }]
        }], propDecorators: { paginator: [{
                type: ViewChild,
                args: [MatPaginator]
            }], totalCount: [{
                type: Input
            }], customPageSize: [{
                type: Input
            }], hidePageSize: [{
                type: Input
            }], defaultPageSize: [{
                type: Input
            }], paginationAction: [{
                type: Output
            }] } });

/* eslint-disable @typescript-eslint/no-explicit-any */
class DateAgoPipe {
    transform(value) {
        const date = new Date(value * 1000);
        if (value) {
            const seconds = Math.floor((+new Date() - +new Date(date)) / 1000);
            if (seconds < 29) {
                // less than 30 seconds ago will show as 'Just now'
                return 'Just now';
            }
            const intervals = {
                year: 31536000,
                month: 2592000,
                week: 604800,
                day: 86400,
                hour: 3600,
                minute: 60,
                second: 1,
            };
            let counter;
            for (const i in intervals) {
                counter = Math.floor(seconds / intervals[i]);
                if (counter > 0)
                    if (counter === 1) {
                        return counter + ' ' + i + ' ago'; // singular (1 day ago)
                    }
                    else {
                        return counter + ' ' + i + 's ago'; // plural (2 days ago)
                    }
            }
        }
        return date;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DateAgoPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: DateAgoPipe, isStandalone: true, name: "dateAgo" }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: DateAgoPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'dateAgo',
                    pure: true,
                    standalone: true,
                }]
        }] });

/* eslint-disable @typescript-eslint/no-explicit-any */
class FilterDropdownPipe {
    transform(items, searchKey) {
        if (!items || !searchKey) {
            return items;
        }
        // filter items array, items which match and return true will be
        // kept, false will be filtered out
        return items.filter(item => item.name.toLowerCase().indexOf(searchKey.toLowerCase()) !== -1);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FilterDropdownPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "16.2.12", ngImport: i0, type: FilterDropdownPipe, isStandalone: true, name: "searchOptions", pure: false }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "16.2.12", ngImport: i0, type: FilterDropdownPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'searchOptions',
                    pure: false,
                    standalone: true,
                }]
        }] });

function AutoUnsubscribe(constructor) {
    // Get a reference to the original ngOnDestroy function of the component/service
    const original = constructor.prototype.ngOnDestroy;
    // Override the ngOnDestroy function of the component/service
    constructor.prototype.ngOnDestroy = function () {
        // Loop through all properties of the component/service
        for (const prop in this) {
            const property = this[prop];
            // Check if the property is a subscription
            if (property && typeof property.unsubscribe === 'function') {
                // Call the unsubscribe function to unsubscribe from the subscription
                property.unsubscribe();
            }
        }
        original?.apply(this, arguments);
    };
}

const HTTP_OPTION_1 = {
    contentType: true,
    token: true,
    userId: true,
    timezone: true,
};
const HTTP_OPTION_2 = {
    token: true,
    userId: true,
    timezone: true,
};
const HTTP_OPTION_3 = {
    contentType: true,
    token: true,
    userId: true,
    nodeId: true,
};
const HTTP_OPTION_4 = {
    token: true,
    userId: true,
    nodeId: true,
    timezone: true,
};
const HTTP_OPTION_5 = {
    token: true,
    contentType: true,
};
const HTTP_OPTION_6 = {
    urlEncode: true,
};

/**
 * Generates HTTP headers based on the provided configuration.
 *
 * @param itemsNeeded - Partial configuration object specifying which headers are needed.
 * @returns HTTP headers options object.
 */
const headerOptions = (itemsNeeded) => {
    // Get user data and company ID from local storage
    const companyId = localStorage.getItem('companyID');
    // Check if impersonation is enabled
    const impersonate = localStorage.getItem('impersonate');
    // Extract needed properties from the configuration object
    const { timezone, contentType, userId, nodeId, token, urlEncode, acceptAll } = itemsNeeded;
    // Initialize the base header object
    const BASE_HEADER = {};
    const idToken = localStorage.getItem('id_token');
    const loggedInUserId = localStorage.getItem('userId');
    // Add User-ID header if needed
    if (userId) {
        BASE_HEADER['User-ID'] = loggedInUserId;
    }
    // Add Bearer token header if needed
    if (token) {
        BASE_HEADER['Authorization'] = `Bearer ${idToken}`;
    }
    // Add Node-ID header if needed
    if (nodeId) {
        BASE_HEADER['Node-ID'] = companyId;
    }
    // Add timezone header if needed
    if (timezone) {
        BASE_HEADER['timezone'] = Intl.DateTimeFormat().resolvedOptions().timeZone;
    }
    // Add Content-Type header if needed
    if (contentType) {
        BASE_HEADER['Content-Type'] = 'application/json';
    }
    // Add X-Impersonate header if impersonation is enabled
    if (impersonate) {
        BASE_HEADER['X-Impersonate'] = 'true';
    }
    if (urlEncode) {
        BASE_HEADER['Content-Type'] = 'application/x-www-form-urlencoded';
    }
    if (acceptAll) {
        BASE_HEADER['Accept'] = '*/*';
    }
    // Create HTTP headers options object
    const httpOptions = {
        headers: new HttpHeaders({
            ...BASE_HEADER,
        }),
    };
    return httpOptions;
};

/*
 * Public API Surface of fairfood-utils
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ActionButtonsComponent, AutoUnsubscribe, ButtonsComponent, DateAgoPipe, FairFoodCustomTabComponent, FfPaginationComponent, FilterDropdownPipe, HTTP_OPTION_1, HTTP_OPTION_2, HTTP_OPTION_3, HTTP_OPTION_4, HTTP_OPTION_5, HTTP_OPTION_6, LoaderComponent, LoaderType, SortCustomComponent, headerOptions };
//# sourceMappingURL=fairfood-utils.mjs.map
