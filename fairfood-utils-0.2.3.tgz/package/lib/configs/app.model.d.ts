type FieldNames = 'contentType' | 'token' | 'timezone' | 'userId' | 'nodeId' | 'urlEncode' | 'acceptAll';
export type IhttpHeadConfig = {
    [K in FieldNames]: boolean;
};
export {};
