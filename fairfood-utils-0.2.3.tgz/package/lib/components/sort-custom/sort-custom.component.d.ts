import * as i0 from "@angular/core";
export declare class SortCustomComponent {
    filterValues: any;
    columnName: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SortCustomComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SortCustomComponent, "app-sort-custom", never, { "filterValues": { "alias": "filterValues"; "required": false; }; "columnName": { "alias": "columnName"; "required": false; }; }, {}, never, never, true, never>;
}
